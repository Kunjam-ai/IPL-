const jwt = require('jsonwebtoken');

// Middleware to verify JWT token
const authenticateToken = (req, res, next) => {
  // Get token from Authorization header
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN format
  
  if (!token) {
    return res.status(401).json({ message: 'Access denied. No token provided.' });
  }
  
  try {
    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (error) {
    return res.status(403).json({ message: 'Invalid token.' });
  }
};

// Middleware to check if user is admin
const isAdmin = (req, res, next) => {
  if (req.user && req.user.role === 'admin') {
    next();
  } else {
    return res.status(403).json({ message: 'Access denied. Admin privileges required.' });
  }
};

// Middleware to check if user is tournament creator or admin
const isTournamentCreatorOrAdmin = async (req, res, next) => {
  try {
    const { tournamentId } = req.params;
    const userId = req.user.id;
    
    // Check if user is admin
    if (req.user.role === 'admin') {
      return next();
    }
    
    // Check if user is tournament creator
    const { pool } = require('../../database/init');
    const result = await pool.query(
      'SELECT creator_user_id FROM tournaments WHERE tournament_id = $1',
      [tournamentId]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Tournament not found.' });
    }
    
    if (result.rows[0].creator_user_id === userId) {
      return next();
    }
    
    return res.status(403).json({ message: 'Access denied. Only tournament creator or admin can perform this action.' });
  } catch (error) {
    console.error('Error in isTournamentCreatorOrAdmin middleware:', error);
    return res.status(500).json({ message: 'Server error.' });
  }
};

module.exports = {
  authenticateToken,
  isAdmin,
  isTournamentCreatorOrAdmin
};
